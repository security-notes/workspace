#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <dir.h>

// OllyDbg v1.06����Ή�����ׂɁAPDK1.06�g�p
// �����N���A�C���|�[�g���C�u������ 1.06 ���g�p���邱��
#include "odbg\plugin106.h"

#define PNAME   "j10n"
#define PVERS   "v1.40.106"
#define ANAME   "DokoDon"
#define EMAIL   "e-mail: dokodon@hotmail.com"

HINSTANCE  hinst;                // DLL instance
HWND       hwmain;               // Handle of main OllyDbg window
HHOOK      hHook = NULL;
HFONT      hFont = NULL;
CHOOSEFONT cf;
LOGFONT    lf;
DWORD *phfont = NULL;

int bm_search(const BYTE *b, const int blen, const BYTE *p, const int plen);
int main_window_font_change(void);
int enable_editbox_font_change(void);
void disable_editbox_font_change(void);
void choose_font(void);
int Steel_IstextA(void);
LRESULT CALLBACK CallWndRetProc(int code,  WPARAM wParam,  LPARAM lParam);
BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam);

BOOL WINAPI DllEntryPoint(HINSTANCE hi,DWORD reason,LPVOID reserved)
{
  if (reason==DLL_PROCESS_ATTACH)
    hinst=hi;                          // Mark plugin instance
  return 1;                            // Report success
}

extc int _export cdecl ODBG_Plugindata(char shortname[32])
{
  strcpy(shortname,PNAME);       // Name of plugin
  return PLUGIN_VERSION;
}

extc int _export cdecl ODBG_Plugininit(int ollydbgversion,HWND hw,DWORD *features)
{
  if(ollydbgversion<PLUGIN_VERSION) {
    return -1;
  }
  hwmain=hw;
  Addtolist(0, 0,PNAME" "PVERS"  by "ANAME);

  // �t�H���g�쐬
  ZeroMemory(&lf,sizeof(LOGFONT));
  Pluginreadstringfromini(hinst,"FontFace",lf.lfFaceName,"MS UI Gothic");
  lf.lfHeight  = Pluginreadintfromini(hinst,"FontHeight",12);
  lf.lfCharSet = (BYTE)Pluginreadintfromini(hinst,"CharSet",SHIFTJIS_CHARSET);
  hFont = CreateFontIndirect(&lf);

  enable_editbox_font_change();
  main_window_font_change();
  Steel_IstextA();
  return 0;
};

extc int _export cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item)
{
  switch (origin) {
  case PM_MAIN: // Plugin menu in main window
    //strcpy(data,"0 &Choose Font|" 63 "PNAME" "PVERS" by "ANAME);
    strcpy(data,
         "0 &Choose Font|"
         "1 Enable Editbox Font Change,"
         "2 Disable Editbox Font Change|"
         "63 "PNAME" "PVERS" by "ANAME
         );
    return 1;
  default:
    break; // Any other window
  }
  return 0; // Window not supported by plugin
};

extc void _export cdecl ODBG_Pluginaction(int origin,int action,void *item)
{
  switch(origin) {
  case PM_MAIN:
    switch (action) {
    case 0:
      choose_font();
      break;
    case 1:
      enable_editbox_font_change();
      break;
    case 2:
      disable_editbox_font_change();
      break;
    default:
      break;
    }
  default:
    break;
  }
}

// �I������
extc void _export cdecl ODBG_Plugindestroy() {
  disable_editbox_font_change();
  if(hFont) {
    DeleteObject(hFont);
  }
}

#ifndef max
#define max(a, b)   ((a) > (b) ? a : b)
#endif

// Boyer-Moore �����i�p�^�[���T�[�`�p�j
int bm_search(const BYTE *b, const int blen, const BYTE *p, const int plen)
{
  int skip[256];
  int i,j;

  for(i=0; i<256; i++) {
    skip[i] = plen;
  }
  for(i=0; i<plen-1; i++) {
    skip[*(p+i)] = plen - i - 1;
  }

  i = plen - 1;
  while(i < blen) {
    j = plen - 1;
    while(*(b+i) == *(p+j)) {
      if(j==0) {
        return i;
      }
      i--; j--;
    }
    i += max(skip[*(b+i)], plen - j);
  }
  return -1;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �UIstextA
/////////////////////////////////////////////////////////////////////////////////////////////////////
int niSe_IstextA(char c)
{
  const BYTE org[] = {
    0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x02 ,0x00 ,0x02 ,0x02 ,0x02 ,0x02,
    0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x00 ,0x02 ,0x00 ,0x02 ,0x02 ,0x02 ,0x02,
    0x00 ,0x00 ,0x00 ,0x02 ,0x00 ,0x02 ,0x00 ,0x02 ,0x00 ,0x03 ,0x02 ,0x00 ,0x00 ,0x00 ,0x03 ,0x02,
    0x00 ,0x02 ,0x00 ,0x02 ,0x00 ,0x02 ,0x00 ,0x00 ,0x00 ,0x02 ,0x02 ,0x00 ,0x02 ,0x00 ,0x02 ,0x02,
    0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02,
    0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x00 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02,
    0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02,
    0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02 ,0x00 ,0x02 ,0x02 ,0x02 ,0x02 ,0x02
  };
  BYTE *p, n = 0x03;
  int i,ret;
  DWORD *paddr,addr;

  p = (BYTE *)GetProcAddress((HINSTANCE)Plugingetvalue(VAL_HINST),"_IstextA");
  paddr = (DWORD*)(p + 0x1D);
  addr = *paddr;
  p = (BYTE *)(addr + 0x80);
  // verify
  for(i=0; i<sizeof(org); i++){
    if(*(p+i) != org[i]) {
      return 0;
    }
  }
  // overwrite
  for(i=0; i<sizeof(org); i++){
    *(p+i) = n;
  }
  ret = IstextA(c);
  // overwrite
  for(i=0; i<sizeof(org); i++){
    *(p+i) = org[i];
  }
  return ret;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �Q�ƕ������T���Ƃ��Ɋ֌W���� IstextA �� niSe_IstextA �ɕύX
// OllyDbg�̃G�N�X�|�[�g�֐� "Decodeaddress" �̒��Ŏg���Ă��� "IstextA"
//    Decodeaddress + 6F3
//    Decodeaddress + 722
// ���A�Q�ƕ������T���Ƃ��Ɋ֌W���Ă���B�iOllyDbg ver 1.06�܂Ŋm�F�j
// �������AIstextA ���Q�Ƃ��Ă���e�[�u�������������郋�[�`�������������́i�UIstextA�j�ɕύX����B
/////////////////////////////////////////////////////////////////////////////////////////////////////
int Steel_IstextA(void)
{
  DWORD  offset[2] = {0x06F3, 0x0722};
  DWORD  operand_old, operand_new, operand_calc, pid;
  BYTE   opcode, *pPatch, *pIstextA, *pDecodeaddress;
  HANDLE hP;
  int    i;

  GetWindowThreadProcessId(hwmain,&pid);
  hP = OpenProcess(PROCESS_VM_OPERATION|PROCESS_VM_READ|PROCESS_VM_WRITE,FALSE,pid);

  pDecodeaddress = (BYTE *)GetProcAddress((HINSTANCE)Plugingetvalue(VAL_HINST),"_Decodeaddress");
  pIstextA = (BYTE *)GetProcAddress((HINSTANCE)Plugingetvalue(VAL_HINST),"_IstextA");
  //Addtolist((long)pDecodeaddress,-1,"  "PNAME" Decodeaddress at 0x%08X",(DWORD)pDecodeaddress);
  //Addtolist((long)pIstextA,-1,"  "PNAME" IstextA at 0x%08X",(DWORD)pIstextA);

  for(i=0; i<sizeof(offset)/sizeof(offset[0]); i++) {
    pPatch = pDecodeaddress + offset[i];
    ReadProcessMemory(hP,pPatch,(void*)&opcode,sizeof(BYTE),NULL);
    if(opcode != 0x0E8) {
      return -1;
    }
    pPatch++;
    ReadProcessMemory(hP,pPatch,(void*)&operand_old,sizeof(DWORD),NULL);
    operand_calc = (DWORD)pIstextA-((DWORD)pPatch+4);
    if(operand_calc == operand_old) {
      //Addtolist((long)pPatch-1,-1,"  "PNAME" : at %08X call _IstextA : %02X %08X   calcrated operand:%08X",(long)pPatch-1,opcode,operand_old,operand_calc);
      operand_new = (DWORD)niSe_IstextA - ((DWORD)pPatch+4);
      WriteProcessMemory(hP,pPatch,(void*)&operand_new,sizeof(DWORD),NULL);
      //Addtolist((long)pPatch-1,-1,"  "PNAME" : patched the call addres from 0x%08X to 0x%08X",operand_old,operand_new);
    }
  }
  CloseHandle(hP);
  return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �t�H���g�̑I���i�t�H���g�I���_�C�A���O��\�����A�ݒ�j
/////////////////////////////////////////////////////////////////////////////////////////////////////
void choose_font(void)
{
  ZeroMemory(&cf,sizeof(CHOOSEFONT));
  cf.lStructSize = sizeof(CHOOSEFONT);
  cf.hwndOwner   = NULL;
  cf.lpLogFont   = &lf;
  cf.Flags       = CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT | CF_NOVERTFONTS;
  cf.rgbColors   = RGB(0, 0, 0);
  cf.nFontType   = SCREEN_FONTTYPE;
  if(ChooseFont(&cf)) {
    Pluginwritestringtoini(hinst,"FontFace",lf.lfFaceName);
    Pluginwriteinttoini(hinst,"FontHeight",lf.lfHeight);
    Pluginwriteinttoini(hinst,"CharSet",lf.lfCharSet);
    if(hFont) {
      DeleteObject(hFont);
    }
    hFont = CreateFontIndirect(&lf);
    if(phfont) {
      *phfont = (DWORD)hFont;
      RedrawWindow(hwmain,NULL,NULL,RDW_INVALIDATE|RDW_ALLCHILDREN|RDW_UPDATENOW);
    }
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// OllyDbg�̃��C���E�B���h�E�i���炭�X�e�[�^�X�o�[�݂̂ɗL���j�̃t�H���g����{��Ή��ɂ���
/////////////////////////////////////////////////////////////////////////////////////////////////////
int main_window_font_change(void)
{
  /* ���C���E�B���h�E�p�t�H���g�쐬�����̃o�C�i���p�^�[�� */
  const BYTE ptn[] = {
    0x50, 0x6A, 0x00, 0x6A, 0x02, 0x6A, 0x00, 0x6A, 0x06, 0x6A, 0x01, 0x6A, 0x00, 0x6A, 0x00,
    0x6A, 0x00, 0x68, 0x90, 0x01, 0x00, 0x00, 0x6A, 0x00, 0x6A, 0x00, 0x6A, 0x05, 0x6A, 0x0D
  };
  //** v1.10a **//
  // 00433F16  |.  50                 push    eax                                 ; /FaceName
  // 00433F17  |.  6A 00              push    0                                   ; |PitchAndFamily = DEFAULT_PITCH|FF_DONTCARE
  // 00433F19  |.  6A 02              push    2                                   ; |Quality = PROOF_QUALITY
  // 00433F1B  |.  6A 00              push    0                                   ; |ClipPrecision = CLIP_DEFAULT_PRECIS
  // 00433F1D  |.  6A 06              push    6                                   ; |OutputPrecision = OUT_RASTER_PRECIS
  // 00433F1F  |.  6A 01              push    1                                   ; |CharSet = DEFAULT_CHARSET
  // 00433F21  |.  6A 00              push    0                                   ; |StrikeOut = FALSE
  // 00433F23  |.  6A 00              push    0                                   ; |Underline = FALSE
  // 00433F25  |.  6A 00              push    0                                   ; |Italic = FALSE
  // 00433F27  |.  68 90010000        push    190                                 ; |Weight = FW_NORMAL
  // 00433F2C  |.  6A 00              push    0                                   ; |Orientation = 0
  // 00433F2E  |.  6A 00              push    0                                   ; |Escapement = 0
  // 00433F30  |.  6A 05              push    5                                   ; |Width = 5
  // 00433F32  |.  6A 0D              push    0D                                  ; |Height = D (13.)

  PIMAGE_DOS_HEADER pidh;
  PIMAGE_NT_HEADERS pinh;
  DWORD SizeOfImage;
  int pos;
  BYTE *p;
  DWORD *paddr,addr;

  p = (BYTE*)Plugingetvalue(VAL_HINST);
  pidh = (PIMAGE_DOS_HEADER)p;
  pinh = (PIMAGE_NT_HEADERS)(p+pidh->e_lfanew);
  SizeOfImage = pinh->OptionalHeader.SizeOfImage;
  pos = bm_search(p,SizeOfImage,ptn,sizeof(ptn));
  if(pos == -1) {
    Addtolist(0,-1,"  "PNAME" This OllyDbg seems to be modified!! Can't change the font of main window.");
    phfont = NULL;
    return(0);
  }
  Addtolist((long)(p+pos+sizeof(ptn)+5),-1,"  *The command storing the font of main window at %08X",(p+pos+sizeof(ptn)+5));
  Addtolist(0,-1,"     \(You can see it by loading OllyDbg and double clicking the above line.\)");
  paddr = (DWORD*)(p+pos+sizeof(ptn)+6);
  addr = *paddr;
  phfont = (DWORD*)addr;
  *phfont = (DWORD)hFont;
  Addtolist(0, -1, "  "PNAME" Changed the main window font to \"%s\"",lf.lfFaceName);

  return(1);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �_�C�A���O��Edit�R���g���[���̃t�H���g����{��Ή��̂��̂ɂ���ׂ̃t�b�N�v���V�[�W�����d�|����
/////////////////////////////////////////////////////////////////////////////////////////////////////
int enable_editbox_font_change(void)
{
  hHook = SetWindowsHookEx(WH_CALLWNDPROCRET,CallWndRetProc,NULL,GetCurrentThreadId());
  if(hHook) {
    Addtolist(0, -1, "  "PNAME" Window Hook success! Change dialog font to \"%s\"",lf.lfFaceName);
    return 1;
  }
  else {
    Addtolist(0, -1, "  "PNAME" Window Hook failed.  Can't change Dialog Font.");
    return 0;
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �_�C�A���O��Edit�R���g���[���̃t�H���g����{��Ή��̂��̂ɂ���ׂ̃t�b�N�v���V�[�W������������
/////////////////////////////////////////////////////////////////////////////////////////////////////
void disable_editbox_font_change(void)
{
  if(hHook) {
    UnhookWindowsHookEx(hHook);
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �_�C�A���O��Edit�R���g���[���̃t�H���g����{��Ή��̂��̂ɂ���ׂ̃t�b�N�v���V�[�W��
/////////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK CallWndRetProc(int code, WPARAM wParam, LPARAM lParam)
{
  CWPRETSTRUCT *pCWPR = (CWPRETSTRUCT*)lParam;
  HWND  hwParent,hwBuf;

  if(code < 0) {
    return CallNextHookEx(hHook,code,wParam,lParam);
  }

  switch(pCWPR->message) {
  case WM_INITDIALOG: // �_�C�A���O���쐬���ꂽ�Ƃ�
    // �O�ׁ̈A�e�E�B���h�E��OllyDbg���ǂ����m�F
    hwBuf = GetParent(pCWPR->hwnd);
    do {
      hwParent = hwBuf;
      hwBuf = GetParent(hwBuf);
    } while(hwBuf);
    if(hwParent == hwmain) { // �g�b�v���x���̃E�B���h�E�� OllyDbg �Ȃ�
      EnumChildWindows(pCWPR->hwnd,EnumChildProc,(LPARAM)0); // �q�E�B���h�E���
    }
    break;
  default:
    break;
  }
  return CallNextHookEx(hHook,code,wParam,lParam);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �q�E�B���h�E�񋓃v���V�[�W��
// �񋓂��ꂽ�e�E�B���h�E�ɑ΂��A�N���X���� Edit �Ȃ�΁A�t�H���g��ύX����
/////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK EnumChildProc(HWND hwnd, LPARAM lParam)
{
  char cls[TEXTLEN];

  GetClassName(hwnd,cls,TEXTLEN-1);
  if(!stricmp(cls,"Edit")) {
    SendMessage(hwnd,WM_SETFONT,(WPARAM)hFont,(LPARAM)TRUE);
  }
  return TRUE;
}
